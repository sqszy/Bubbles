package com.example.itog

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class glav : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_glav)
    }
}