package com.example.itog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.content.Intent

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonNavigate1 = findViewById<Button>(R.id.button1)
        buttonNavigate1.setOnClickListener {
            val intent = Intent(this, glav::class.java)
            startActivity(intent)
        }
        //Кнопка с переходом к карте
        val buttonNavigate2 = findViewById<Button>(R.id.button2)
        buttonNavigate2.setOnClickListener {
            // Создаем Intent для перехода на вторую активность
            val intent = Intent(this, Map::class.java)
            startActivity(intent)
        }

    }
}